﻿namespace Basics.Controllers
{
    public interface IAuthentizationService
    {
    }
}